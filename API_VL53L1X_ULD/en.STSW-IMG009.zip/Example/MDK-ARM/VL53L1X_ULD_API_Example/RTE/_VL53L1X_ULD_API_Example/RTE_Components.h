
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'VL53L1X_ULD_API_Example' 
 * Target:  'VL53L1X_ULD_API_Example' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f4xx.h"


#endif /* RTE_COMPONENTS_H */
